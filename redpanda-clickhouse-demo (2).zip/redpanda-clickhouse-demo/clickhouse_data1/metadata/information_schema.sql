ATTACH DATABASE information_schema
ENGINE = Memory
