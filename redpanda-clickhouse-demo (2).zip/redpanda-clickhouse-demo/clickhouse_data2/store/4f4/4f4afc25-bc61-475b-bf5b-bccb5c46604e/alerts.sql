ATTACH TABLE _ UUID '5bc3f855-8669-49cb-b6a2-b630ab3bef69'
(
    `timestamp` DateTime DEFAULT now(),
    `service` String,
    `host` String,
    `cpu_usage` Float64,
    `mem_usage` Float64,
    `level` String,
    `message` String,
    `rule` String,
    `explanation` String
)
ENGINE = MergeTree
ORDER BY (timestamp, service)
SETTINGS index_granularity = 8192
