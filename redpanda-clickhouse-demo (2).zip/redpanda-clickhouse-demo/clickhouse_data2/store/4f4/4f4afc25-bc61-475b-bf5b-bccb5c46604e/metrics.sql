ATTACH TABLE _ UUID 'b9627155-d5eb-4af1-9ef3-c067cab11b90'
(
    `timestamp` DateTime,
    `service` String,
    `host` String,
    `cpu_usage` Float64,
    `mem_usage` Float64,
    `level` String,
    `message` String
)
ENGINE = MergeTree
ORDER BY timestamp
SETTINGS index_granularity = 8192
